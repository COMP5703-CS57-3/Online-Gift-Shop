# from main.logic.login_signup import login_founction
# from app.py import gift_shop

# def add_namespace():
#     gift_shop.add_namespace(login_founction, "/login_signup")